
import { GoogleGenAI, Type } from "@google/genai";
import { PresentationConfig, Slide } from "../types";

// 1. MƏRHƏLƏ: Struktur (Outline) Qurulması
export const generatePresentationOutline = async (
  apiKey: string,
  config: PresentationConfig,
  extractedData?: string
): Promise<Slide[]> => {
  const ai = new GoogleGenAI({ apiKey: apiKey });

  let sourcePrompt = "";
  
  if (extractedData) {
      sourcePrompt = `
      [MƏNBƏ SƏNƏDİN MƏZMUNU]:
      ${extractedData.substring(0, 90000)}
      
      [İSTİFADƏÇİ GİRİŞİ]: "${config.topic}"

      🔴 ANALİZ TƏLİMATI:
      1. Sənədin əsas mövzusunu müəyyən et (məsələn: Maliyyə, Tibb, Təhsil və s.).
      2. Təqdimatın adını sənədin mövzusuna uyğun qoy.
      3. Slaydları elə böl ki, həm məlumat, həm də vizuallıq olsun.
      `;
  } else {
      sourcePrompt = `Təqdimat Mövzusu: "${config.topic}"`;
  }
  
  const prompt = `
    ${sourcePrompt}
    
    Auditoriya: ${config.audience}
    Slayd Sayı: ${config.slideCount}
    Dil: ${config.language}
    
    TƏLƏB: 
    Yuxarıdakı məlumatlara əsasən ${config.slideCount} slayddan ibarət struktur (outline) hazırla.
    
    🎨 VİZUAL BALANS QAYDALARI (ÇOX VACİB):
    1. Slaydların ən azı 60%-i mütləq "image-right" və ya "image-left" layout-unda OLMALIDIR. Bizə şəkillər lazımdır.
    2. "chart" layout-unu YALNIZ konkret rəqəmlər və statistika olan slaydlar (maksimum 1-2 dənə) üçün istifadə et. Hər slaydı diaqram etmə!
    3. "text" layout-undan bacardıqca AZ istifadə et.
    4. Slaydların sırası: Giriş (image) -> Problem (image) -> Statistika (chart) -> Həll (image) -> Nəticə (image).

    JSON FORMATI:
    {
      "slides": [
        {
          "title": "Slaydın Başlığı",
          "layout": "image-right", 
          "keywords": ["açar1", "açar2"]
        }
      ]
    }
  `;

  const response = await ai.models.generateContent({
    model: config.model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          slides: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                layout: { type: Type.STRING, enum: ['image-right', 'image-left', 'chart', 'text', 'comparison', 'title-only'] },
                keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["title", "layout", "keywords"]
            }
          }
        }
      }
    }
  });

  const parsed = JSON.parse(response.text);
  return parsed.slides.map((s: any) => ({ ...s, content: [], visualPrompt: "" }));
};

// 2. MƏRHƏLƏ: Slayd Detalları
export const generateSlideDetail = async (
  apiKey: string,
  config: PresentationConfig,
  slideTitle: string,
  slideKeywords: string[],
  contextData: string | undefined,
  currentSlideIndex: number,
  totalSlides: number,
  previousSlideContent?: string
): Promise<Partial<Slide>> => {
  const ai = new GoogleGenAI({ apiKey: apiKey });
  
  const tools = config.useSearch ? [{ googleSearch: {} }] : [];

  let narrativeInstruction = "";
  if (currentSlideIndex === 0) narrativeInstruction = "Bu giriş slaydıdı. Mövzunu cəlbedici şəkildə təqdim et.";
  else if (currentSlideIndex === totalSlides - 1) narrativeInstruction = "Bu nəticə slaydıdı. Yekunlaşdır.";
  else narrativeInstruction = `Mövzunu detallı izah et.`;

  const prompt = `
    Slayd Başlığı: "${slideTitle}"
    Dil: ${config.language}
    Hekayə Təlimatı: ${narrativeInstruction}
    ${previousSlideContent ? `Əvvəlki slaydın məntiqi davamı olsun.` : ""}
    ${contextData ? `[MƏNBƏ FAKTLAR]:\n${contextData.substring(0, 90000)}` : ''}

    TƏLƏB:
    1. "content": Slayd üçün 1 və ya 2 ədəd BÜTÖV, AXICI PARAQRAF yaz (siyahı yox).
    2. "visualPrompt": Slaydın mövzusuna uyğun foto-realistik şəkil təsviri yaz (İngilis dilində). Məsələn: "A futuristic office with digital graphs..."
    3. Əgər "chart" layout-udursa, "chart" datasını mütləq doldur.

    JSON Scheme:
    {
      "content": ["Paraqraf 1...", "Paraqraf 2..."],
      "speakerNotes": "...",
      "visualPrompt": "Detailed image description in English...",
      "footer": "...",
      "chart": {
         "type": "bar",
         "title": "Diaqram Başlığı",
         "labels": ["A", "B"],
         "values": [10, 20]
      }
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: config.model,
      contents: prompt,
      config: {
        tools: tools,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            content: { type: Type.ARRAY, items: { type: Type.STRING } },
            speakerNotes: { type: Type.STRING },
            visualPrompt: { type: Type.STRING },
            footer: { type: Type.STRING },
            chart: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, enum: ['bar', 'pie', 'line', 'radar'] },
                    title: { type: Type.STRING },
                    labels: { type: Type.ARRAY, items: { type: Type.STRING } },
                    values: { type: Type.ARRAY, items: { type: Type.NUMBER } }
                }
            }
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Slide detail error", error);
    return {
        content: ["Məlumat hazırda əlçatan deyil."],
        speakerNotes: "",
        visualPrompt: ""
    };
  }
};

export const generateImageForSlide = async (apiKey: string, prompt: string): Promise<string | null> => {
  if (!prompt || prompt.length < 5) return null;
  try {
    const ai = new GoogleGenAI({ apiKey: apiKey });
    // Şəkil promptunu gücləndiririk
    const enhancedPrompt = `Cinematic, high quality, professional presentation image: ${prompt}`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: [{ parts: [{ text: enhancedPrompt }] }],
      config: { imageConfig: { aspectRatio: "16:9" } }
    });
    const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    return part ? `data:image/png;base64,${part.inlineData.data}` : null;
  } catch { return null; }
};

export const refineSlideText = async (apiKey: string, text: string, instruction: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: apiKey });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview", 
    contents: `Bu mətni yenidən yaz: "${text}". Təlimat: ${instruction}`,
  });
  return response.text?.trim() || text;
};
