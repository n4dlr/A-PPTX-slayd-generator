
import React, { useState, useRef, useEffect } from 'react';
import { 
  FileText, Settings, Download, Loader2, Upload, Monitor, Zap, Trash2, 
  Image as ImageIcon, BarChart3, Key, Languages, Layers, Users, Tag, MessageSquare, Copy,
  Globe, Save, FolderOpen, RefreshCcw, Edit3, Wand2, Plus, ArrowUp, ArrowDown, XCircle,
  Cpu, X, Sparkles, Check, Type as TypeIcon, Palette, Grid, Sliders
} from 'lucide-react';
import { PresentationConfig, Language, Theme, Font, AspectRatio, Slide, Audience, AIModel } from './types';
import { generatePresentationOutline, generateSlideDetail, generateImageForSlide, refineSlideText } from './services/geminiService';
import { createPptxFile } from './services/pptxService';

declare const JSZip: any;

export const App: React.FC = () => {
  const [config, setConfig] = useState<PresentationConfig>({
    topic: '',
    slideCount: 8,
    language: Language.AZ,
    theme: Theme.PROFESSIONAL,
    font: Font.ARIAL, // Default Font
    audience: Audience.GENERAL,
    aspectRatio: AspectRatio.WIDESCREEN,
    fontSize: 18,
    sentencesPerSlide: 4,
    additionalContext: '',
    generateImages: true,
    useSearch: false,
    model: AIModel.GEMINI_3_FLASH
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [processingSlideId, setProcessingSlideId] = useState<string | null>(null);
  const [generatedSlides, setGeneratedSlides] = useState<Slide[]>([]);
  const [error, setError] = useState<{ message: string; isQuota: boolean } | null>(null);
  
  const [apiKey, setApiKey] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<{name: string, content: string}[]>([]);
  const [activeSlideIndex, setActiveSlideIndex] = useState<number | null>(null);
  
  const projectInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const slideContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeSlideIndex !== null && slideContainerRef.current) {
        const elements = slideContainerRef.current.children;
        if (elements[activeSlideIndex]) {
            elements[activeSlideIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
  }, [activeSlideIndex]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    setLoadingStep('Sənədlər oxunur...');
    const newFiles: {name: string, content: string}[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        if (file.name.endsWith('.zip')) {
          const zip = await JSZip.loadAsync(file);
          for (const filename of Object.keys(zip.files)) {
            if (!zip.files[filename].dir) {
              const content = await zip.files[filename].async('string');
              newFiles.push({ name: filename, content: content.substring(0, 10000) });
            }
          }
        } else {
          const content = await file.text();
          newFiles.push({ name: file.name, content: content.substring(0, 10000) });
        }
      } catch (err) { console.error(err); }
    }
    setAttachedFiles(prev => [...prev, ...newFiles]);
    setLoadingStep('');
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);
    setLoadingStep('Dayandırıldı.');
    setActiveSlideIndex(null);
  };

  const handleGenerate = async () => {
    if (isLoading) {
      handleCancel();
      return;
    }
    if (!apiKey) {
      setError({ message: "API Key daxil edilməyib.", isQuota: false });
      return;
    }
    if (!config.topic && attachedFiles.length === 0) {
      setError({ message: "Mövzu yazın və ya sənəd yükləyin.", isQuota: false });
      return;
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    setIsLoading(true);
    setError(null);
    setGeneratedSlides([]);
    setLoadingStep('Struktur qurulur (Outline)...');
    
    const combinedFileContext = attachedFiles.map(f => `Fayl: ${f.name}\nMəzmun: ${f.content}`).join('\n\n');

    try {
      const outline = await generatePresentationOutline(apiKey, config, combinedFileContext);
      if (controller.signal.aborted) return;
      
      setGeneratedSlides(outline);
      setLoadingStep('Slaydlar doldurulur...');

      const fullSlides = [...outline];
      for (let i = 0; i < fullSlides.length; i++) {
        if (controller.signal.aborted) break;
        
        setActiveSlideIndex(i);
        setLoadingStep(`Slayd ${i + 1}/${fullSlides.length} yazılır...`);

        const previousContent = i > 0 ? fullSlides[i-1].content.join(" ") : undefined;

        const details = await generateSlideDetail(
            apiKey, 
            config, 
            fullSlides[i].title, 
            fullSlides[i].keywords, 
            combinedFileContext, 
            i, 
            fullSlides.length,
            previousContent
        );
        if (controller.signal.aborted) break;

        fullSlides[i] = { ...fullSlides[i], ...details };
        setGeneratedSlides([...fullSlides]);

        if (config.generateImages && details.visualPrompt) {
            generateImageForSlide(apiKey, details.visualPrompt).then(img => {
                if (img && !controller.signal.aborted) {
                    setGeneratedSlides(currentSlides => {
                        const updated = [...currentSlides];
                        if (updated[i]) updated[i].imageB64 = img;
                        return updated;
                    });
                }
            });
        }
        await new Promise(r => setTimeout(r, 500));
      }
      
      setLoadingStep('Hazırdır!');
      setActiveSlideIndex(null);
      setIsLoading(false);

    } catch (err: any) {
      if (err.name === 'AbortError') return;
      setError({ 
        message: err.message?.includes('429') ? "Limit dolub (Quota Exceeded)." : (err.message || 'Xəta.'),
        isQuota: err.message?.includes('429')
      });
      setIsLoading(false);
    }
  };

  const handleExportPPTX = async () => {
    if (generatedSlides.length === 0) return;
    setIsExporting(true);
    try {
      await createPptxFile(generatedSlides, config);
    } catch (e: any) {
      alert("Xəta: " + (e.message || "Bilinməyən xəta"));
      console.error(e);
    } finally {
      setIsExporting(false);
    }
  };

  const enhancePrompt = async () => {
     if(!apiKey || !config.topic) return;
     setLoadingStep('Prompt yaxşılaşdırılır...');
     try {
         const refined = await refineSlideText(apiKey, config.topic, "Bu mövzunu təqdimat üçün daha peşəkar və geniş bir prompt halına gətir. YALNIZ yeni prompt mətnini qaytar. Heç bir giriş sözü yazma.");
         setConfig({...config, topic: refined});
     } catch(e) { console.error(e); }
     setLoadingStep('');
  };

  const handleRefineText = async (slideIdx: number, contentIdx: number, text: string, type: string) => {
    if (!apiKey) return;
    setProcessingSlideId(`refine-${slideIdx}-${contentIdx}`);
    const instructions: any = { shorten: "Qısalt", expand: "Genişləndir", professional: "Rəsmi üslub" };
    try {
      const newText = await refineSlideText(apiKey, text, instructions[type]);
      const updated = [...generatedSlides];
      updated[slideIdx].content[contentIdx] = newText;
      setGeneratedSlides(updated);
    } catch (e) {}
    setProcessingSlideId(null);
  };

  const addNewSlide = () => setGeneratedSlides([...generatedSlides, {
      title: "Yeni Slayd", content: ["Mətn daxil edin..."], layout: "text", keywords: ["MANUAL"], visualPrompt: "Abstract background"
  }]);

  const updateSlideContent = (sIdx: number, cIdx: number, val: string) => {
      const u = [...generatedSlides]; u[sIdx].content[cIdx] = val; setGeneratedSlides(u);
  };

  const saveProject = () => {
    const blob = new Blob([JSON.stringify({ config, generatedSlides }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `project.json`; a.click();
  };

  const loadProject = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return;
    const r = new FileReader(); r.onload = (ev) => { try { const d = JSON.parse(ev.target?.result as string); setConfig(d.config); setGeneratedSlides(d.generatedSlides); } catch(x){} }; r.readAsText(f);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#020617] text-slate-100 selection:bg-indigo-500/30 overflow-x-hidden">
      {/* Navbar */}
      <nav className="glass sticky top-0 z-50 px-4 md:px-8 py-4 flex items-center justify-between border-b border-white/5 shadow-2xl w-full">
        <div className="flex items-center gap-4">
          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg shadow-indigo-500/20">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div className="hidden md:block">
            <h1 className="text-xl font-black bg-gradient-to-r from-indigo-400 via-white to-cyan-400 bg-clip-text text-transparent uppercase tracking-tighter">
              AI SLIDES ULTRA
            </h1>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-black">Real-time Edition</span>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2 md:gap-3 items-center">
          {generatedSlides.length > 0 && (
            <button onClick={saveProject} className="hidden md:flex items-center gap-2 px-4 py-2 bg-white/5 rounded-xl text-[10px] font-bold hover:bg-white/10 border border-white/10 transition-all focus:outline-none focus:border-indigo-500">
              <Save className="w-3.5 h-3.5" /> SAVƏ
            </button>
          )}
          <button onClick={() => projectInputRef.current?.click()} className="hidden md:flex items-center gap-2 px-4 py-2 bg-white/5 rounded-xl text-[10px] font-bold hover:bg-white/10 border border-white/10 transition-all focus:outline-none focus:border-indigo-500">
            <FolderOpen className="w-3.5 h-3.5" /> LOAD
          </button>
          <input type="file" ref={projectInputRef} className="hidden" accept=".json" onChange={loadProject} />

          {/* API Key Input */}
          <div className="group relative flex items-center justify-end transition-all duration-300 ease-out w-10 hover:w-48 md:hover:w-64 focus-within:w-48 md:focus-within:w-64 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 hover:border-indigo-500/50 focus-within:border-indigo-500 overflow-hidden ml-2 h-10 shadow-inner">
            <div className="absolute left-3 flex items-center pointer-events-none z-10">
              <Key className={`w-4 h-4 ${apiKey ? 'text-emerald-400' : 'text-slate-400'}`} />
            </div>
            <input 
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="API Key..."
              className="w-full h-full pl-10 pr-4 bg-transparent text-[10px] font-bold tracking-widest text-white placeholder:text-slate-500 outline-none border-none opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity cursor-pointer group-focus-within:cursor-text"
              autoComplete="new-password"
            />
          </div>
        </div>
      </nav>

      <main className="flex-1 w-full max-w-[1600px] mx-auto p-4 md:p-6 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
        
        {/* Settings Panel */}
        <section className="lg:col-span-4 space-y-8 min-w-0">
          <div className="glass rounded-[2.5rem] p-6 md:p-8 space-y-8 border border-white/10 shadow-3xl sticky top-28">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black flex items-center gap-3 uppercase tracking-tight text-slate-300">
                <Settings className="w-5 h-5 text-indigo-500" /> Strateji Tənzimləmə
              </h2>
              {attachedFiles.length > 0 && (
                <button onClick={() => setAttachedFiles([])} className="text-[9px] text-red-400 hover:text-red-300 font-bold uppercase tracking-widest transition-colors focus:outline-none">
                  Reset
                </button>
              )}
            </div>
            
            <div className="space-y-6 max-h-[calc(100vh-350px)] pr-2 overflow-y-auto custom-scrollbar">
              
              {/* Error Message */}
              {error && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-300 text-xs font-bold flex items-center gap-3 animate-pulse">
                  <XCircle className="w-5 h-5 shrink-0" />
                  <div>
                    <p>{error.message}</p>
                    {error.isQuota && (
                      <button onClick={() => setConfig({...config, model: AIModel.GEMINI_3_FLASH})} className="mt-2 text-[10px] underline hover:text-white">
                        Avtomatik 'Flash' rejiminə keç
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Prompt Area - FIXED */}
              <div className="relative group/prompt">
                <div className="flex justify-between items-center mb-2">
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Ssenari / Mövzu</label>
                </div>
                <div className="relative bg-slate-900/60 border border-white/10 rounded-[1.5rem] transition-colors hover:border-white/20 focus-within:border-indigo-500 focus-within:bg-slate-900/80 overflow-hidden">
                    <textarea
                        dir="ltr"
                        value={config.topic}
                        onChange={(e) => setConfig({ ...config, topic: e.target.value })}
                        placeholder="Məsələn: '2025 Rəqəmsal Marketinq Strategiyası'..."
                        className="w-full bg-slate-950/30 p-6 text-base text-white min-h-[160px] focus:outline-none placeholder:text-slate-600 font-medium resize-none leading-relaxed custom-scrollbar selection:bg-indigo-500/40 pb-12 text-left"
                    />
                    <div className="absolute bottom-4 right-4 flex gap-2">
                         {config.topic && (
                            <>
                                <button onClick={() => setConfig({ ...config, topic: '' })} className="p-2 bg-slate-800 text-slate-400 rounded-xl border border-white/5 hover:bg-rose-500/20 hover:text-rose-400 transition-colors"><X className="w-3.5 h-3.5" /></button>
                                <button onClick={enhancePrompt} disabled={!apiKey} className="p-2 bg-indigo-600 text-white rounded-xl border border-indigo-400/30 shadow-lg shadow-indigo-500/20 hover:bg-indigo-500"><Sparkles className="w-3.5 h-3.5" /></button>
                            </>
                         )}
                    </div>
                </div>
              </div>

              {/* Visual Style Settings */}
              <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2 border-b border-white/5 pb-2">
                      <Palette className="w-3 h-3" /> Vizual Stil
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                       {/* Theme */}
                       <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Dizayn</label>
                          <select value={config.theme} onChange={(e) => setConfig({...config, theme: e.target.value as Theme})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500">
                             {Object.values(Theme).map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                       </div>
                       {/* Font */}
                       <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Şrift</label>
                          <select value={config.font} onChange={(e) => setConfig({...config, font: e.target.value as Font})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500">
                             {Object.values(Font).map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                       </div>
                       {/* Aspect Ratio */}
                       <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Format</label>
                          <select value={config.aspectRatio} onChange={(e) => setConfig({...config, aspectRatio: e.target.value as AspectRatio})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500">
                             {Object.values(AspectRatio).map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                       </div>
                       {/* Language */}
                       <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Dil</label>
                          <select value={config.language} onChange={(e) => setConfig({...config, language: e.target.value as Language})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500">
                             {Object.values(Language).map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                       </div>
                  </div>
              </div>

              {/* Content Strategy Settings */}
              <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2 border-b border-white/5 pb-2">
                      <Sliders className="w-3 h-3" /> Məzmun Strategiyası
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                      {/* Slide Count */}
                      <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Slayd Sayı</label>
                          <input type="number" min="1" max="40" value={config.slideCount} onChange={(e) => setConfig({...config, slideCount: parseInt(e.target.value) || 1})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"/>
                      </div>
                      {/* Sentences Per Slide */}
                      <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400">Cümlə/Slayd</label>
                          <input type="number" min="1" max="10" value={config.sentencesPerSlide} onChange={(e) => setConfig({...config, sentencesPerSlide: parseInt(e.target.value) || 4})} className="w-full bg-slate-900/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"/>
                      </div>
                  </div>
                  {/* Toggles */}
                  <div className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/5">
                      <span className="text-xs font-bold text-slate-300 flex items-center gap-2"><ImageIcon className="w-3.5 h-3.5"/> AI Şəkillər</span>
                      <button onClick={() => setConfig({...config, generateImages: !config.generateImages})} className={`w-10 h-5 rounded-full relative transition-colors ${config.generateImages ? 'bg-indigo-500' : 'bg-slate-700'}`}>
                          <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${config.generateImages ? 'left-6' : 'left-1'}`} />
                      </button>
                  </div>
              </div>

               {/* AI Model Selector */}
               <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest flex items-center gap-2">
                    <Cpu className="w-3 h-3" /> AI Model
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    <button 
                      onClick={() => setConfig({ ...config, model: AIModel.GEMINI_3_FLASH })}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all focus:outline-none ${config.model === AIModel.GEMINI_3_FLASH ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300' : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:border-white/10'}`}
                    >
                      <div className="flex flex-col items-start">
                        <span className="text-xs font-bold">Gemini 3 Flash</span>
                        <span className="text-[9px] opacity-70">Sürətli (High Quota)</span>
                      </div>
                      {config.model === AIModel.GEMINI_3_FLASH && <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />}
                    </button>
                    <button 
                      onClick={() => setConfig({ ...config, model: AIModel.GEMINI_3_PRO })}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all focus:outline-none ${config.model === AIModel.GEMINI_3_PRO ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:border-white/10'}`}
                    >
                      <div className="flex flex-col items-start">
                        <span className="text-xs font-bold">Gemini 3 Pro</span>
                        <span className="text-[9px] opacity-70">Maksimum Ağıl</span>
                      </div>
                      {config.model === AIModel.GEMINI_3_PRO && <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" />}
                    </button>
                  </div>
               </div>

              {/* File Upload Area */}
              <div className="group relative">
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest flex items-center gap-2">
                  <Upload className="w-3 h-3" /> Mənbə Sənədlər
                </label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-white/10 rounded-[1.5rem] p-4 text-center cursor-pointer hover:border-indigo-500/50 hover:bg-white/5 transition-all"
                >
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-indigo-300">
                    Sənədləri Yüklə (PDF/DOCX/TXT)
                  </p>
                  <input type="file" ref={fileInputRef} className="hidden" multiple onChange={handleFileUpload} accept=".zip,.txt,.js,.json,.pdf,.docx" />
                </div>
                {attachedFiles.length > 0 && (
                  <div className="mt-2 flex flex-col gap-2">
                    {attachedFiles.map((f, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-white/5 rounded-lg border border-white/5 text-[10px] text-slate-300">
                        <span className="truncate max-w-[150px]">{f.name}</span>
                        <button onClick={(e) => { e.stopPropagation(); removeFile(i); }}><Trash2 className="w-3 h-3 hover:text-red-400" /></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Button */}
              <button
                onClick={handleGenerate}
                disabled={!apiKey}
                className={`w-full py-5 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 border border-white/10 focus:outline-none ${
                  isLoading 
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/50' 
                    : !apiKey 
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 hover:from-indigo-500 hover:to-purple-700 text-white shadow-indigo-900/50'
                }`}
              >
                {isLoading ? <XCircle className="w-5 h-5 animate-pulse" /> : <Zap className="w-5 h-5" />} 
                {isLoading ? 'DAYANDIR' : 'Təqdimatı Generasiya Et'}
              </button>
            </div>
          </div>
        </section>

        {/* Preview Panel (Right Side) */}
        <section className="lg:col-span-8 space-y-8 min-w-0">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black text-white flex items-center gap-3 uppercase tracking-tighter">
              <Monitor className="w-6 h-6 text-cyan-500" /> Slayd Kanvası
            </h2>
            <div className="flex gap-2 items-center">
              {isLoading && (
                  <div className="flex items-center gap-3 bg-indigo-900/40 border border-indigo-500/30 px-4 py-2 rounded-xl animate-pulse mr-2">
                     <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                     <span className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">{loadingStep}</span>
                  </div>
              )}
              {generatedSlides.length > 0 && (
                <>
                  <button onClick={addNewSlide} className="hidden sm:flex bg-white/5 hover:bg-white/10 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-300 transition-all border border-white/10 items-center gap-2 focus:outline-none focus:border-indigo-500">
                    <Plus className="w-4 h-4" /> Əlavə Et
                  </button>
                  <button 
                    onClick={handleExportPPTX} 
                    disabled={isExporting}
                    className="bg-indigo-600 hover:bg-indigo-500 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-white shadow-xl shadow-indigo-900/30 transition-all border border-indigo-400/20 flex items-center gap-2 focus:outline-none focus:border-indigo-400"
                  >
                    {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} 
                    {isExporting ? 'Yaradılır...' : 'PPTX İxrac Et'}
                  </button>
                </>
              )}
            </div>
          </div>

          {!isLoading && generatedSlides.length === 0 && (
            <div className="h-[650px] border-2 border-dashed border-white/5 rounded-[3.5rem] flex flex-col items-center justify-center text-slate-500 p-12 text-center bg-white/[0.01] group hover:bg-white/[0.02] transition-all">
              <div className="w-28 h-28 bg-white/5 rounded-full flex items-center justify-center mb-8 border border-white/5 group-hover:scale-110 transition-transform">
                <Layers className="w-12 h-12 text-slate-800" />
              </div>
              <p className="text-3xl font-black text-slate-400 uppercase tracking-tighter">Təqdimat mühiti hazırdır</p>
              <p className="text-[10px] max-w-xs mt-4 opacity-40 font-black uppercase tracking-[0.2em]">Parametrləri daxil edib strateji sənədi başladın.</p>
            </div>
          )}

          <div ref={slideContainerRef} className="space-y-12 max-h-[85vh] overflow-y-auto pr-4 custom-scrollbar pb-32 scroll-smooth">
            {generatedSlides.map((slide, idx) => (
              <div key={idx} className={`glass rounded-[3rem] p-6 md:p-12 border transition-all shadow-4xl relative group overflow-visible duration-700 ${activeSlideIndex === idx ? 'border-indigo-500/50 shadow-indigo-500/10 bg-indigo-950/20' : 'border-white/5 hover:border-indigo-500/30'}`}>
                {/* Active Indicator */}
                {activeSlideIndex === idx && (
                    <div className="absolute top-12 right-12 flex items-center gap-2 text-indigo-400 animate-pulse">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-[9px] font-black uppercase tracking-widest">Yazılır...</span>
                    </div>
                )}
                
                {/* Title */}
                 <div className="border-l-[12px] border-indigo-600 pl-6 md:pl-8 mb-10">
                    <input 
                    value={slide.title}
                    onChange={(e) => {const u=[...generatedSlides]; u[idx].title=e.target.value; setGeneratedSlides(u)}}
                    className="w-full bg-transparent text-2xl md:text-4xl font-black text-white uppercase tracking-tighter outline-none border-b border-transparent hover:border-white/10 focus:border-indigo-500 transition-colors break-words"
                    style={{fontFamily: config.font}}
                    />
                </div>

                {/* Content - FIXED: Rendering as Text Areas instead of List Items */}
                <div className="space-y-6 min-h-[100px]">
                    {slide.content.map((p, i) => (
                        <div key={i} className="relative group/content">
                            <textarea 
                                value={p}
                                onChange={(e) => updateSlideContent(idx, i, e.target.value)}
                                rows={Math.max(3, Math.ceil(p.length / 80))}
                                className="w-full bg-transparent text-slate-300 text-base md:text-lg font-medium outline-none resize-none border-l-2 border-transparent hover:border-white/20 focus:border-indigo-500 pl-4 transition-colors leading-relaxed"
                                style={{fontFamily: config.font}}
                            />
                             {/* Magic buttons */}
                             <div className="hidden group-hover/content:flex gap-2 absolute -bottom-6 left-4 z-10">
                                <button onClick={() => handleRefineText(idx, i, p, 'expand')} className="px-2 py-1 bg-indigo-900/80 rounded text-[9px] text-indigo-200 hover:bg-indigo-700 flex items-center gap-1 border border-indigo-500/30"><Wand2 className="w-2 h-2" /> Genişləndir</button>
                            </div>
                        </div>
                    ))}
                </div>

                 {/* Chart Preview */}
                 {slide.chart && (
                     <div className="mt-8 p-6 bg-slate-900/50 rounded-3xl border border-white/10">
                         <div className="flex items-center gap-2 mb-4 text-emerald-400">
                             <BarChart3 className="w-5 h-5" />
                             <span className="text-xs font-bold uppercase tracking-wider">Diaqram: {slide.chart.type}</span>
                         </div>
                         <div className="h-32 flex items-end justify-around gap-2 px-4">
                             {slide.chart.values.map((v, k) => (
                                 <div key={k} className="w-12 bg-emerald-500/30 rounded-t-lg relative group/bar hover:bg-emerald-500 transition-colors" style={{height: `${(v / Math.max(...slide.chart!.values)) * 100}%`}}>
                                     <div className="absolute -top-6 w-full text-center text-[10px] font-bold text-white">{v}</div>
                                     <div className="absolute -bottom-6 w-full text-center text-[10px] text-slate-400 truncate">{slide.chart?.labels[k]}</div>
                                 </div>
                             ))}
                         </div>
                     </div>
                 )}

                {/* Image Section */}
                 <div className="mt-8 space-y-6">
                    {slide.layout.includes('image') && config.generateImages && (
                      <div className="rounded-[2.5rem] overflow-hidden border border-white/10 shadow-3xl group/img relative aspect-[16/10] bg-slate-900 flex items-center justify-center">
                        {slide.imageB64 ? (
                            <img src={slide.imageB64} alt="AI Art" className="w-full h-full object-cover group-hover/img:scale-110 transition-transform duration-[2000ms]" />
                        ) : (
                            <div className="text-center p-6 opacity-40">
                                <ImageIcon className="w-10 h-10 text-slate-700 mx-auto" />
                                <p className="text-[10px] mt-2 font-bold uppercase tracking-widest">Şəkil gözlənilir...</p>
                            </div>
                        )}
                      </div>
                    )}
                  </div>
              </div>
            ))}
          </div>
        </section>
      </main>
      
      <footer className="py-12 px-10 text-center border-t border-white/5 text-slate-800 text-[10px] uppercase tracking-[0.8em] font-black">
        &copy; 2025 AI PRO SLIDES GENERATOR
      </footer>
    </div>
  );
};
