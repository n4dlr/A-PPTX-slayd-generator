
export enum Language {
  AZ = 'Azerbaijani',
  EN = 'English',
  TR = 'Turkish',
  RU = 'Russian'
}

export enum Theme {
  ACADEMIC = 'Academic',
  PROFESSIONAL = 'Professional',
  CREATIVE = 'Creative',
  MINIMALIST = 'Minimalist',
  BOLD = 'Bold/Dark'
}

export enum Font {
  ARIAL = 'Arial',
  ROBOTO = 'Roboto',
  TIMES = 'Times New Roman',
  COURIER = 'Courier New',
  VERDANA = 'Verdana'
}

export enum Audience {
  GENERAL = 'General Public',
  INVESTORS = 'Business/Investors',
  STUDENTS = 'Academic/Students',
  TECHNICAL = 'Developers/Technical',
  KIDS = 'Children/Beginners'
}

export enum AspectRatio {
  WIDESCREEN = '16:9',
  STANDARD = '4:3',
  A4 = 'A4'
}

export enum AIModel {
  GEMINI_3_PRO = 'gemini-3-pro-preview',
  GEMINI_3_FLASH = 'gemini-3-flash-preview',
  GEMINI_2_FLASH = 'gemini-2.0-flash'
}

export interface ChartData {
  type: 'bar' | 'pie' | 'line' | 'radar';
  labels: string[];
  values: number[];
  title: string;
}

export interface Slide {
  title: string;
  content: string[];
  footer?: string;
  layout: 'text' | 'image-right' | 'image-left' | 'chart' | 'comparison' | 'title-only';
  visualPrompt?: string;
  imageB64?: string;
  chart?: ChartData;
  keywords: string[]; // Slayd üçün açar sözlər
  speakerNotes?: string; // Məruzəçi üçün qeydlər
}

export interface PresentationConfig {
  topic: string;
  slideCount: number;
  language: Language;
  theme: Theme;
  font: Font; // Yeni: Şrift seçimi
  audience: Audience;
  aspectRatio: AspectRatio;
  fontSize: number;
  sentencesPerSlide: number; // Yeni: Slayddakı mətn sıxlığı
  additionalContext: string;
  generateImages: boolean; // Yeni: Şəkilləri söndürüb yandırmaq
  useSearch: boolean;
  model: AIModel;
}
